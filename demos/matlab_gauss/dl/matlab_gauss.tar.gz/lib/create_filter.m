%% create gaussian filter

function h = create_filter(sigma)

w = max(3, ceil(sigma*2));
h = fspecial('gaussian',[w w], sigma);
